-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3307
-- Generation Time: Apr 11, 2023 at 02:27 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ospjsp`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `email` varchar(100) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `mobileNumber` bigint(20) DEFAULT NULL,
  `orderDate` varchar(100) DEFAULT NULL,
  `deliveryDate` varchar(100) DEFAULT NULL,
  `paymentMethod` varchar(100) DEFAULT NULL,
  `transactionId` varchar(100) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`email`, `product_id`, `quantity`, `price`, `total`, `address`, `city`, `state`, `country`, `mobileNumber`, `orderDate`, `deliveryDate`, `paymentMethod`, `transactionId`, `status`) VALUES
('Alex@gmail.com', 1, 5, 1000, 5000, 'London', 'London', 'London', 'UK', 9988383891, '2021-01-19 10:52:18', '2021-01-26 10:52:18', 'Cash on delivery(COD)', '', 'Delivered'),
('Alex@gmail.com', 2, 2, 2000, 4000, 'London', 'London', 'London', 'UK', 9988383891, '2021-01-19 10:52:18', '2021-01-26 10:52:18', 'Cash on delivery(COD)', '', 'Cancel'),
('Alex@gmail.com', 3, 3, 3000, 9000, 'London', 'London', 'London', 'UK', 9988383891, '2021-01-19 10:52:18', '2021-01-26 10:52:18', 'Cash on delivery(COD)', '', 'Delivered'),
('Alex@gmail.com', 4, 4, 8000, 32000, 'Manchester', 'Manchester', 'Manchester', 'UK', 9988383891, '2021-01-19 10:52:18', '2021-01-26 10:52:18', 'Cash on delivery(COD)', '', 'Delivered'),
('Oliver@gmail.com', 3, 2, 3000, 6000, 'Oliver@gmail.com', 'Manchester', 'Manchester', 'UK', 9988383891, '2021-02-11 20:24:55', '2021-02-18 20:24:55', 'Cash on delivery(COD)', '', 'Delivered'),
('Oliver@gmail.com', 2, 2, 2000, 4000, 'Oliver@gmail.com','Manchester', 'Manchester', 'Uk', 9988383891, '2021-02-11 20:24:55', '2021-02-18 20:24:55', 'Cash on delivery(COD)', '', 'Cancel');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `id` int(11) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `subject` varchar(200) DEFAULT NULL,
  `body` varchar(1000) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`id`, `email`, `subject`, `body`) VALUES
(1, 'Alex@gmail.com', 'Great', 'Great'),
(2, 'Zoe@gmail.com', 'hey', 'Sai ee website'),
(3, 'abc@gmail.com', 'hello', 'badhia project ee');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(500) DEFAULT NULL,
  `category` varchar(200) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `active` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `category`, `price`, `active`) VALUES
(1, 'puma', 'Shoe', 1000, 'Yes'),
(2, 'nike', 'Shoe', 2000, 'Yes'),
(3, 'adidas', 'Shoe', 3000, 'Yes'),
(4, 'jeans', 'denim', 8000, 'Yes'),
(5, 'Jacket', 'Jacket1', 5000, 'Yes'),
(6, 'jane', ' jacket', 545, 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `mobileNumber` bigint(20) DEFAULT NULL,
  `securityQuestion` varchar(200) DEFAULT NULL,
  `answer` varchar(200) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`name`, `email`, `mobileNumber`, `securityQuestion`, `answer`, `password`, `address`, `city`, `state`, `country`) VALUES
('Alex', 'Alex@gmail.com', 4499883838, 'What was your first car?', 'maruti', '123', 'London', 'London', 'London', 'UK'),
('Zoe', 'Zoe@gmail.com', 4473216540, 'What is the name of the town you were born?', 'manchester', '12', 'manchester', 'manchester', 'manchester', 'UK'),
('Rocky', 'Rocky@gmail.com', 4488383891, 'What is the name of your first pet?', 'dog', '125', 'manchester', 'manchester', 'manchester', 'UK'),
('Oliver', 'Oliver@gmail.com', 44988383891, 'What was your first car?', 'Maruti', '456', 'London', 'London', 'London', 'UK'),
('Ray Plammer', 'RayPlammer@gmail.com', 4488383891, 'What is the name of your first pet?', 'dog', '321', 'Glasgow', 'Glasgow', 'Glasgow', 'UK');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
